## Scaleway CLI autocomplete plugin

[scw](https://github.com/scaleway/scaleway-cli): Manage Bare Metal servers from Command Line (as easily as with Docker)

- Adds autocomplete options for all `scw` commands.

Maintainer : Manfred Touron ([@moul](https://github.com/moul))
